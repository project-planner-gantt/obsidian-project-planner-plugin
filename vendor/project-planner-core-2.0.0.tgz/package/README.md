# Project Gantt Core

Shared Markdown planning logic and Gantt editor for **Project Gantt**, created by **bvn13**.

The package combines a TypeScript document engine with a Svelte 5 / SVAR Gantt interface. It is used by the [Obsidian plugin](https://gitea.bvn13.me/management/obsidian-project-planner-plugin) and the [Tauri desktop application](https://gitea.bvn13.me/management/project-planner-2).

The package name remains `@project-planner/core`. It is currently a private local package, not a published npm dependency.

## Screenshots

The shared editor hosted by the Obsidian plugin, displaying the bundled [development-plan demo](samples/demo-project.md). The interface is set to English; task names remain in the original Russian Markdown.

![Shared Project Gantt editor showing task groups, dependencies, dates, and progress inside Obsidian](docs/images/project-gantt-overview.png)

The shared task dialog edits dates, status tags, stages, progress, and Markdown notes:

![Shared task editor with scheduling fields and Markdown notes](docs/images/project-gantt-task-editor.png)

## Dependencies

| Dependency | Requirement | Purpose |
| --- | --- | --- |
| [Obsidian Tasks](https://github.com/obsidian-tasks-group/obsidian-tasks) | **Optional companion plugin for Obsidian users** | The task syntax is based on the Tasks emoji metadata format. Tasks is not needed to parse or edit documents, and the core does not import or call its API. |
| Svelte 5 | Required peer dependency for the shared UI | Component framework and reactive runtime for the Gantt editor and dialogs. The engine's root entry point does not import Svelte. |
| `@svar-ui/svelte-gantt` | Required for the shared UI | Renders the Gantt chart, task bars, and dependency links. |
| `@svar-ui/svelte-core` and `@svar-ui/core-locales` | Required for the shared UI | Calendar widgets, themes, and English/Russian widget localization. |
| CodeMirror 6 and `@lezer/highlight` | Required for the shared UI | Markdown editing and syntax highlighting in task and group notes. |
| `yaml` | Required by the document engine | Parses YAML project frontmatter. The built root entry point keeps this package as an external dependency. |
| Node.js, npm, TypeScript, Vite, and the Svelte Vite plugin | Development/build only | Install packages, compile the engine, and build consuming applications. |
| Vitest and svelte-check | Development only | Unit testing and Svelte/TypeScript validation. |

Exact versions are recorded in [package.json](package.json) and `package-lock.json`. Obsidian and Tauri are host integrations, not dependencies of the TypeScript document engine.

**Task format compatibility:** only a subset of Tasks-style metadata is supported. Project Gantt also uses its own progress markers, milestone/stage tags, and block-ID-based dependencies. These extensions should not be interpreted as full Tasks compatibility. The original date markers are documented in the [Tasks date-format guide](https://github.com/obsidian-tasks-group/obsidian-tasks/blob/main/docs/Getting%20Started/Dates.md).

## Package responsibilities

- Parse Markdown projects, headings, tasks, dates, and dependencies.
- Map project documents to chart rows.
- Edit task lines, groups, ordering, nesting, and project settings.
- Track document and linked-file changes through host-provided storage.
- Detect stale edits and serialize updates within each store.
- Render the shared chart, task dialogs, stage filters, and settings.

Platform file dialogs, recent-file lists, and Obsidian workspace navigation belong to the host application. The shared interface supports English and Russian.

## Localization

Language preference types, validation, system-language resolution, and dictionaries live in [src/core/i18n.ts](src/core/i18n.ts). The preference is `system`, `en`, or `ru`; unsupported system languages resolve to English. The module has no UI or platform dependency.

Pass a resolved `language` (`en` or `ru`) to `Planner`. Each instance provides its own translation and SVAR locale context through [src/ui/i18n.ts](src/ui/i18n.ts). The language is selected when the component mounts; remount the component when changing it. Svelte hosts can wrap it in `{#key language}`. The default remains Russian for existing integrations that omit this prop.

The host owns preference storage: Obsidian uses plugin data; the desktop application uses a user configuration file. Language is not a project frontmatter setting. Project titles, task text, tags, custom markers, and the Markdown date format are not translated. Date inputs retain the unambiguous `DD.MM.YYYY` format; calendar month/day labels follow the selected locale.

The desktop HTML viewer receives the resolved language in its export payload. Older exports without a language retain Russian as their fallback.

## Development

Use Node.js and npm. The installed Vitest version supports Node.js `^22.12.0 || ^24.0.0 || >=26.0.0`; Node.js 24 satisfies this range.

```sh
npm ci
npm run check:core
npm run check
npm test
npm run build
```

| Command | Purpose |
| --- | --- |
| `check:core` | Type-check the TypeScript document engine |
| `check` | Check Svelte components and TypeScript |
| `test` | Run unit tests |
| `build` | Generate `dist/index.js` and declarations under `dist/types/` |

The root entry point does not import Svelte, the DOM, Tauri, or Obsidian. YAML frontmatter parsing uses `yaml`. UI components are exported as Svelte source for the consuming application's build pipeline.

Build definitions: [package.json](package.json), [tsconfig.build.json](tsconfig.build.json), and [vite.core.config.ts](vite.core.config.ts).

## Repository layout

The current applications use sibling checkouts:

```text
workspace/
  project-planner-core/
  project-planner-2/
  obsidian-project-planner-plugin/
```

Both consumers depend on `file:../project-planner-core`. Install and build this package first, then run `npm ci` in the consumer. Both use Vite with the Svelte plugin and `resolve.dedupe: ["svelte"]` to share a single Svelte runtime. Dependency versions are recorded in package manifests and lockfiles.

The original `project-planner` application is preserved separately and is not required to build these repositories.

## Package entry points

| Import | Contents |
| --- | --- |
| `@project-planner/core` | Built TypeScript engine and declarations |
| `@project-planner/core/core/*` | Individual TypeScript source modules for bundlers |
| `@project-planner/core/ui` | Shared `Planner.svelte` component |
| `@project-planner/core/ui/*` | UI helpers; use the `.svelte` suffix for component imports |
| `@project-planner/core/styles.css` | Shared styles scoped under `.pp-scope` |
| `@project-planner/core/fonts.css` | Local fonts and SVAR icons |

The exact export map is defined in [package.json](package.json).

## Host integration

Implement [DocumentStorage](src/core/document.ts) using your platform's document APIs:

```ts
export interface DocumentStorage {
  readText(path: string): Promise<string>;
  writeText(path: string, content: string): Promise<void>;
  exists(path: string): Promise<boolean>;
  watch(path: string, onChange: (force?: boolean) => void): Promise<() => void>;
  updateText?(path: string, update: (fresh: string) => string): Promise<string>;
  resolveLink?(name: string, fromPath: string): Promise<string | null>;
}
```

`watch` returns a cleanup function. `resolveLink` supplies host-specific link resolution. If provided, `updateText` must apply its callback to fresh content within an atomic host operation. The Obsidian adapter uses `Vault.process`. Without this method, the store uses an optimistic read/check/write sequence that cannot guarantee atomicity between independent processes.

Create one `ProjectStore` per view, open the document, and pass the store to the shared component. For a browser/Svelte host:

```ts
import { mount, unmount } from "svelte";
import { ProjectStore, DEFAULT_SETTINGS, type DocumentStorage } from "@project-planner/core";
import Planner from "@project-planner/core/ui";
import "@project-planner/core/fonts.css";
import "@project-planner/core/styles.css";

async function openPlanner(target: HTMLElement, storage: DocumentStorage, path: string) {
  const store = new ProjectStore(storage, DEFAULT_SETTINGS);
  try {
    await store.open(path);
    const component = mount(Planner, { target, props: { store } });
    return async () => {
      store.close();
      await unmount(component);
    };
  } catch (error) {
    store.close();
    throw error;
  }
}
```

Call the returned cleanup function when the host view closes.

The component accepts `toolbarStart`, `toolbarEnd`, and `empty` Svelte snippets for host-specific controls. Use `initialLayout` and `onlayoutchange` to restore and persist column widths and grid width. `onready` exposes the chart API and a callback to refresh the current-day marker.

Integration sources: [store](src/core/store.ts), [storage contract](src/core/document.ts), and [Planner component](src/ui/Planner.svelte).

## Document behavior

Documents use Markdown headings, checklist tasks, date markers, and block IDs. See [samples/demo-project.md](samples/demo-project.md) and [samples/external.md](samples/external.md).

Opening a document can write missing task block IDs (`^id`) back to the source. Stores preserve LF/CRLF line endings, watch project and linked documents, and reject edits based on stale snapshots. Task dialogs retain the snapshot against which they were opened.

Each view owns its store and interface state. Shared styles use `.pp-scope`; generated project colors are scoped to each planner instance.

## Tests and extraction baseline

The unit suite covers parsing, mapping, Markdown rendering, task and group edits, ordering and nesting, date/status behavior, and store conflict handling. Run it with `npm test`.

[source-baseline.json](source-baseline.json) records SHA-256 hashes of the original application's sources, tests, and samples at the start of extraction, including changes uncommitted at that time. It exists to verify that extraction preserved the original application. The original repository is not a runtime or build dependency.

## License

Copyright (c) 2026 bvn13. Distributed under the [Project Gantt No-Sale License 1.0](LICENSE).

Personal and commercial use, modification, and free redistribution are permitted. Selling copies or paid forks, paid software bundles containing the covered code, and paid hosted access require separate written permission from bvn13. Paid support, training, installation, and development services are permitted subject to the license conditions. Third-party components retain their own licenses.

This is a source-available project with restrictions on paid distribution, not an OSI-approved open-source license. The full license text governs.

<!-- docs-source: repository=https://gitea.bvn13.me/management/project-planner-core.git; branch=feature/project-gantt; commit=bfe628b4ed4a898797618ac56d875dff85a99b79; tag=; path=README.md; dirty=true -->
